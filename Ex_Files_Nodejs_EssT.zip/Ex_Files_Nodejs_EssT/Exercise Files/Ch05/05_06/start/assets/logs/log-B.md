LOG B
=====
