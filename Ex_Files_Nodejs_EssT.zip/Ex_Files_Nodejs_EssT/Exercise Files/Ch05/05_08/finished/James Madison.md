James Madison
==================

* Philosophy is common sense with big words 
* The circulation of confidence is better than the circulation of money 
* I'm hungry 
